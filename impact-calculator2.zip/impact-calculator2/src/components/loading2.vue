<template>
  <div class="main-container">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" 
        href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" 
        integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" 
        crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <div class="container">
        <img src="../assets/loading2.gif" alt="">
          <h1>Preparing your manure!</h1>
    </div>
  </div>
</template>

<script>

export default {
  components:{
    
  },
  data () {
    return {
      
    }
  }
}
</script>

<style lang='scss'>
.container{
    display: flex;
    justify-content: center;
    align-items: center;
    width:100%;
    height:100vh;
}
.container img{
    max-width: 60%;
    height: auto;
}
h1{
  bottom:11.0%;
    position: absolute;
    font-family: Titillium Web;
    font-style: normal;
    font-weight: 900;
    font-size: 36px;
    line-height: 55px;
    display: flex;
    align-items: center;
    text-align: center;
    letter-spacing: 0.05em;

    color: #40050C;

}
</style>
