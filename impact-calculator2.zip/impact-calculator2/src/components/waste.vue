<template>

  <div class="main-container">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" 
        href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" 
        integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" 
        crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <router-link to="/"><i class='bx fa bxs-home top1-i'></i></router-link>
    <div class="header">
      <div class="icons">
         <h1 class="imp"> Impact Calculator</h1>
        </div>
        <!-- <img   src="" alt=""> -->
        <div class="menu">
        <router-link to="/"><i class='bx hi fa bxs-home'></i></router-link>
         <router-link to="/"><i class="fas hi fa-arrow-left"></i></router-link>
      </div>
    </div>
      <div class="container">
          <div class="title1">Waste Generated</div>
          <p>You generate {{total_waste_gen}} tonnes of waste</p>
                 <div class="image">
            <img class="a" id="loading" src="../assets/51.png" alt="">
            <img class="b" src="../assets/6.png" alt="">
          </div>
         
          <h2>It is as heavy as {{no_of_buses}} buses.</h2>
          <div class="btns"> 
          <button v-on:click="replaceWaste()" class="btn1">See your Carbon Footprint </button>
          <button v-on:click="openLoading2()" class="btn2">Check your compost</button>
          </div>
      </div>
      <router-link to="/resultA"><i class="fas fa-arrow-left  last-i"></i></router-link>
  </div>

</template>

<script>

export default {
  components:{
    
  },
  data () {
    return {
      total_waste_gen:0,
      no_of_buses:0,
    }
  },
  methods:{
    replaceWaste(){
      this.$router.replace('/carbon');
    },
    openLoading2(){
        this.$router.replace('/loading2');
    },
    openresultA(){
      this.$router.replace('/resultA');
    }
  },
  mounted(){
      this.total_waste_gen = this.data.members*0.5*365*60*0.00110231;
      this.total_waste_gen = this.total_waste_gen.toFixed(2);
      this.no_of_buses = this.total_waste_gen/20;
      this.no_of_buses = this.no_of_buses.toFixed(1);
      console.log(this.data);
  },
  props:['data']
}
</script>

<style lang='scss' scoped>

*{
      font-family: Titillium Web;
      margin: 0px;
      padding: 0px;
}
.header{
  display: none;
}

.top1-i{
      position: absolute;
      font-size: 24px;
      top: 40px;
      left: 40px;
      color: white;
      padding: 10px;
      border-radius: 50%;
      // background: #7ABBB0;
    }
    .top1-i:hover{
      cursor: pointer;
      background: #7ABBB0;
    }
    .main-container{
  width: 100%;
  background: #40050C;
//  height: 100vh;
}
.container{
  display: flex;
  flex-direction:column;
  justify-content:flex-start;
  align-items: center;
  height: 110vh;
}

.title1{
	margin-top:10px;
  max-width: 100%;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 72px;
  line-height: 105px;
  display: flex;
  align-items: center;
  color: #FFFFFF;
}

.container p{
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 300;
  font-size: 36px;
  line-height: 55px;
  display: flex;
  align-items: center;
  letter-spacing: -0.015em;
  color: #F2F2F2;
}

h2{
font-style: normal;
font-weight: 600;
font-size: 30px;
line-height: 61px;
display: flex;
align-items: center;
letter-spacing: -0.015em;
color: #F2F2F2;
}

.btns{
	margin-top:15px;
	width:100%;
	display:flex;
	flex-direction:row;
	justify-content:center;
	height:auto;
  margin-bottom:30px;
}

.btn1{
width: 453.03px;
height: 65.77px;
border: 2px solid rgba(29, 132, 143, 0.5);
font-style: normal;
font-weight: 900;
font-size: 32px;
line-height: 55px;

align-items: center;
justify-content: center;
color: #1D848F;
background: rgba(29, 132, 143, 0.5);
border-radius: 64px;
margin-right:20px;
}
.btn1:hover{
  background: #1D848F;
	cursor:pointer;
}

.btn2{
width: 453.03px;
height: 65.77px;
border: 2px solid #1D848F;
box-sizing: border-box;
border-radius: 50px;
font-style: normal;
font-weight: 900;
font-size: 32px;
line-height: 55px;
display: flex;
align-items: center;
justify-content: center;
letter-spacing: 0.05em;
color: #FFFFFF;
background:transparent;
}
.btn2:hover{
	background: #1D848F;
  cursor:pointer;

}

.last-i{
    position: absolute;
    left: 4%;
    bottom: 15%;
    color: white;
    font-size: 24px;
    box-sizing: border-box;
    border: 1px solid #70D3CB;
    padding: 6px;
    border-radius: 50%;
}

.image{
     // background: green;
     margin-top:50px;
      width:70%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
    .a{
      margin-left: 50px;
      width:inherit;
      height: auto;
    //  transform: rotate(20deg);
    }
    .b{
    //  background: black;
      width:150px;
      margin-top:0;
    }

    #loading {
    -webkit-animation: rotation 4s infinite linear;
}

@-webkit-keyframes rotation {
    from {
        -webkit-transform: rotate(0deg);
    }
    to {
        -webkit-transform: rotate(11deg);
    }
}



@media all and (max-width: 900px){
	.btns{
		flex-direction:column;
		align-items:center;
	}
	.btn1{
		margin-bottom:25px;
		margin-right:0;
	}

   .image{
    width:90%;
  }
}

@media all and (max-width:750px){

  .top1-i{
    display:none;
  }
  .last-i{
    display:none;
  }
	.title1{
    margin-top:40px;
		width:100%;
		display:flex;
		justify-content:center;
		font-size:55px;
	}
	.container p{
		margin-top:-3%;
		font-size:25px;
	}

  .image{
    width:90%;
  }
  .b{
    width:100px;
  }
  .header{
  z-index:100;
   top: 0px;
   width: 100%;
  height: 55px;
  position: fixed;
  display:flex;
  justify-content: space-between;
  align-items: center;
  background: #40050C;
}

    .imp{
      margin-left:10%;
      width:100%;
    font-family: Titillium Web;
    font-style: normal;
    font-weight: normal;
    font-size: 24px;
    line-height: 20px;
    color: #FFFFFF;
    }

    .menu{
  margin-right: 5%;
  display:flex;
  justify-content:center;
  align-items:center;
}

    .hi{
    font-size: 20px;
    color: white;
    padding: 5px;
    border: 1px solid #70D3CB;
    box-sizing: border-box;
    border-radius: 50%;
    margin:10px;
    }

}

@media all and (max-width:500px){

.title1{
  font-size:38px;
}
.container p{
  font-size:22px;
  margin-top:-8%;
}
.btn1{
  width:310px;
  height:52px;
  line-height:50px;
  font-size:24px;
  align-items:center;
}
.btn2{
  width:310px;
   height:50px;
    font-size:24px;
  align-items:center;
}
.btns{
  margin-bottom:50px;
}
}

</style>
